package com.shopme.ShopmeFrontend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopmeFrontendApplicationTests {

	@Test
	void contextLoads() {
	}

}
